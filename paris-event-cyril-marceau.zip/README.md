# Files

Projet disponible à cette adresse [Paris event](https://projets.cyril-marceau.com/paris-event/).

## Installation des dépendances

> Allez à la racine du répertoire
> `$ yarn`

## Développement

    $ yarn start

## Build

    $ yarn build
